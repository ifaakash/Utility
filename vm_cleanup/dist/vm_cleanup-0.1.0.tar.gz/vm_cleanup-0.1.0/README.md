# 🚀 Docker Cleanup CLI Utility

![Version](https://img.shields.io/badge/version-0.1.0-blue.svg)

> A lightweight CLI tool to assist with cleaning up Docker images and reclaiming disk space on virtual machines.

---

## ✨ Features

- 🔥 Prompt-based Docker image cleanup
- ⚡ Helps manage disk space on VMs
- 🛠️ Lightweight and easy to use

---

## 📦 Installation

Install the CLI using the following command:

```bash
<xyz>

## 🛤️ Roadmap

- [x] Basic Docker image cleanup
- [ ] Auto-detect and prune unused containers
- [ ] Integration with additional services
- [ ] Scheduled automatic cleanups
- [ ] Smarter space optimization techniques
